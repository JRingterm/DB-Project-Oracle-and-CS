﻿
namespace DBProject
{
    partial class mypage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.orderview_btn = new System.Windows.Forms.Button();
            this.addcard_btn = new System.Windows.Forms.Button();
            this.addaddress_btn = new System.Windows.Forms.Button();
            this.basket_btn = new System.Windows.Forms.Button();
            this.mycard_cbox = new System.Windows.Forms.ComboBox();
            this.cardnum_txtbox = new System.Windows.Forms.TextBox();
            this.m_y_txtbox = new System.Windows.Forms.TextBox();
            this.card_cbox = new System.Windows.Forms.ComboBox();
            this.cardnum1_txtbox = new System.Windows.Forms.TextBox();
            this.cardnum2_txtbox = new System.Windows.Forms.TextBox();
            this.cardnum3_txtbox = new System.Windows.Forms.TextBox();
            this.cardnum4_txtbox = new System.Windows.Forms.TextBox();
            this.month_txtbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.year_txtbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.detail_txtbox = new System.Windows.Forms.TextBox();
            this.basic_txtbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.post_txtbox = new System.Windows.Forms.TextBox();
            this.work_radio = new System.Windows.Forms.RadioButton();
            this.home_radio = new System.Windows.Forms.RadioButton();
            this.name_label = new System.Windows.Forms.Label();
            this.id_label = new System.Windows.Forms.Label();
            this.information_btn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.deletecard_btn = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.fixaddress_btn = new System.Windows.Forms.Button();
            this.cwork_radio = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.chome_radio = new System.Windows.Forms.RadioButton();
            this.deleteaddress_btn = new System.Windows.Forms.Button();
            this.cdetail_txtbox = new System.Windows.Forms.TextBox();
            this.cbasic_txtbox = new System.Windows.Forms.TextBox();
            this.cpost_txtbox = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // orderview_btn
            // 
            this.orderview_btn.Location = new System.Drawing.Point(315, 9);
            this.orderview_btn.Name = "orderview_btn";
            this.orderview_btn.Size = new System.Drawing.Size(148, 63);
            this.orderview_btn.TabIndex = 0;
            this.orderview_btn.Text = "주문조회";
            this.orderview_btn.UseVisualStyleBackColor = true;
            this.orderview_btn.Click += new System.EventHandler(this.orderview_btn_Click);
            // 
            // addcard_btn
            // 
            this.addcard_btn.Location = new System.Drawing.Point(469, 85);
            this.addcard_btn.Name = "addcard_btn";
            this.addcard_btn.Size = new System.Drawing.Size(148, 68);
            this.addcard_btn.TabIndex = 1;
            this.addcard_btn.Text = "내 카드등록";
            this.addcard_btn.UseVisualStyleBackColor = true;
            this.addcard_btn.Click += new System.EventHandler(this.addcard_btn_Click);
            // 
            // addaddress_btn
            // 
            this.addaddress_btn.Location = new System.Drawing.Point(469, 116);
            this.addaddress_btn.Name = "addaddress_btn";
            this.addaddress_btn.Size = new System.Drawing.Size(148, 76);
            this.addaddress_btn.TabIndex = 2;
            this.addaddress_btn.Text = "배송지 등록";
            this.addaddress_btn.UseVisualStyleBackColor = true;
            this.addaddress_btn.Click += new System.EventHandler(this.addaddress_btn_Click);
            // 
            // basket_btn
            // 
            this.basket_btn.Location = new System.Drawing.Point(493, 9);
            this.basket_btn.Name = "basket_btn";
            this.basket_btn.Size = new System.Drawing.Size(146, 63);
            this.basket_btn.TabIndex = 3;
            this.basket_btn.Text = "장바구니 조회";
            this.basket_btn.UseVisualStyleBackColor = true;
            this.basket_btn.Click += new System.EventHandler(this.basket_btn_Click);
            // 
            // mycard_cbox
            // 
            this.mycard_cbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mycard_cbox.FormattingEnabled = true;
            this.mycard_cbox.Location = new System.Drawing.Point(17, 55);
            this.mycard_cbox.Name = "mycard_cbox";
            this.mycard_cbox.Size = new System.Drawing.Size(115, 23);
            this.mycard_cbox.TabIndex = 5;
            this.mycard_cbox.SelectedIndexChanged += new System.EventHandler(this.mycard_cbox_SelectedIndexChanged);
            // 
            // cardnum_txtbox
            // 
            this.cardnum_txtbox.Location = new System.Drawing.Point(163, 55);
            this.cardnum_txtbox.Name = "cardnum_txtbox";
            this.cardnum_txtbox.Size = new System.Drawing.Size(288, 25);
            this.cardnum_txtbox.TabIndex = 6;
            // 
            // m_y_txtbox
            // 
            this.m_y_txtbox.Location = new System.Drawing.Point(163, 111);
            this.m_y_txtbox.Name = "m_y_txtbox";
            this.m_y_txtbox.Size = new System.Drawing.Size(89, 25);
            this.m_y_txtbox.TabIndex = 7;
            // 
            // card_cbox
            // 
            this.card_cbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.card_cbox.FormattingEnabled = true;
            this.card_cbox.Items.AddRange(new object[] {
            "BC카드",
            "KB국민카드",
            "삼성카드",
            "신한카드",
            "우리카드",
            "하나카드",
            "롯데카드",
            "현대카드",
            "NH농협카드"});
            this.card_cbox.Location = new System.Drawing.Point(17, 69);
            this.card_cbox.Name = "card_cbox";
            this.card_cbox.Size = new System.Drawing.Size(115, 23);
            this.card_cbox.TabIndex = 9;
            // 
            // cardnum1_txtbox
            // 
            this.cardnum1_txtbox.Location = new System.Drawing.Point(163, 67);
            this.cardnum1_txtbox.MaxLength = 4;
            this.cardnum1_txtbox.Name = "cardnum1_txtbox";
            this.cardnum1_txtbox.Size = new System.Drawing.Size(62, 25);
            this.cardnum1_txtbox.TabIndex = 10;
            this.cardnum1_txtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Num_only);
            // 
            // cardnum2_txtbox
            // 
            this.cardnum2_txtbox.Location = new System.Drawing.Point(231, 67);
            this.cardnum2_txtbox.MaxLength = 4;
            this.cardnum2_txtbox.Name = "cardnum2_txtbox";
            this.cardnum2_txtbox.Size = new System.Drawing.Size(66, 25);
            this.cardnum2_txtbox.TabIndex = 11;
            this.cardnum2_txtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Num_only);
            // 
            // cardnum3_txtbox
            // 
            this.cardnum3_txtbox.Location = new System.Drawing.Point(303, 67);
            this.cardnum3_txtbox.MaxLength = 4;
            this.cardnum3_txtbox.Name = "cardnum3_txtbox";
            this.cardnum3_txtbox.Size = new System.Drawing.Size(66, 25);
            this.cardnum3_txtbox.TabIndex = 12;
            this.cardnum3_txtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Num_only);
            // 
            // cardnum4_txtbox
            // 
            this.cardnum4_txtbox.Location = new System.Drawing.Point(375, 67);
            this.cardnum4_txtbox.MaxLength = 4;
            this.cardnum4_txtbox.Name = "cardnum4_txtbox";
            this.cardnum4_txtbox.Size = new System.Drawing.Size(66, 25);
            this.cardnum4_txtbox.TabIndex = 13;
            this.cardnum4_txtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Num_only);
            // 
            // month_txtbox
            // 
            this.month_txtbox.Location = new System.Drawing.Point(163, 135);
            this.month_txtbox.MaxLength = 2;
            this.month_txtbox.Name = "month_txtbox";
            this.month_txtbox.Size = new System.Drawing.Size(39, 25);
            this.month_txtbox.TabIndex = 14;
            this.month_txtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Num_only);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(160, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 15);
            this.label4.TabIndex = 15;
            this.label4.Text = "유효기간(M/Y)";
            // 
            // year_txtbox
            // 
            this.year_txtbox.Location = new System.Drawing.Point(224, 135);
            this.year_txtbox.MaxLength = 2;
            this.year_txtbox.Name = "year_txtbox";
            this.year_txtbox.Size = new System.Drawing.Size(39, 25);
            this.year_txtbox.TabIndex = 16;
            this.year_txtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Num_only);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(207, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 15);
            this.label3.TabIndex = 17;
            this.label3.Text = "/";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(161, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 15);
            this.label5.TabIndex = 18;
            this.label5.Text = "카드번호";
            // 
            // detail_txtbox
            // 
            this.detail_txtbox.Location = new System.Drawing.Point(101, 155);
            this.detail_txtbox.Name = "detail_txtbox";
            this.detail_txtbox.Size = new System.Drawing.Size(309, 25);
            this.detail_txtbox.TabIndex = 26;
            // 
            // basic_txtbox
            // 
            this.basic_txtbox.Location = new System.Drawing.Point(101, 113);
            this.basic_txtbox.Name = "basic_txtbox";
            this.basic_txtbox.Size = new System.Drawing.Size(309, 25);
            this.basic_txtbox.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 24;
            this.label6.Text = "상세주소";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 23;
            this.label7.Text = "기본주소";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 15);
            this.label8.TabIndex = 22;
            this.label8.Text = "우편번호";
            // 
            // post_txtbox
            // 
            this.post_txtbox.Location = new System.Drawing.Point(101, 71);
            this.post_txtbox.Name = "post_txtbox";
            this.post_txtbox.Size = new System.Drawing.Size(309, 25);
            this.post_txtbox.TabIndex = 21;
            // 
            // work_radio
            // 
            this.work_radio.AutoSize = true;
            this.work_radio.Location = new System.Drawing.Point(284, 37);
            this.work_radio.Name = "work_radio";
            this.work_radio.Size = new System.Drawing.Size(58, 19);
            this.work_radio.TabIndex = 20;
            this.work_radio.Text = "직장";
            this.work_radio.UseVisualStyleBackColor = true;
            this.work_radio.CheckedChanged += new System.EventHandler(this.work_radio_CheckedChanged);
            // 
            // home_radio
            // 
            this.home_radio.AutoSize = true;
            this.home_radio.Location = new System.Drawing.Point(101, 37);
            this.home_radio.Name = "home_radio";
            this.home_radio.Size = new System.Drawing.Size(58, 19);
            this.home_radio.TabIndex = 19;
            this.home_radio.Text = "자택";
            this.home_radio.UseVisualStyleBackColor = true;
            this.home_radio.CheckedChanged += new System.EventHandler(this.home_radio_CheckedChanged);
            // 
            // name_label
            // 
            this.name_label.AutoSize = true;
            this.name_label.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.name_label.Location = new System.Drawing.Point(37, 26);
            this.name_label.Name = "name_label";
            this.name_label.Size = new System.Drawing.Size(32, 28);
            this.name_label.TabIndex = 27;
            this.name_label.Text = "님";
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.Location = new System.Drawing.Point(344, 126);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(20, 15);
            this.id_label.TabIndex = 28;
            this.id_label.Text = "ID";
            // 
            // information_btn
            // 
            this.information_btn.Location = new System.Drawing.Point(138, 9);
            this.information_btn.Name = "information_btn";
            this.information_btn.Size = new System.Drawing.Size(148, 63);
            this.information_btn.TabIndex = 29;
            this.information_btn.Text = "회원정보 변경";
            this.information_btn.UseVisualStyleBackColor = true;
            this.information_btn.Click += new System.EventHandler(this.information_btn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.addcard_btn);
            this.groupBox1.Controls.Add(this.card_cbox);
            this.groupBox1.Controls.Add(this.cardnum1_txtbox);
            this.groupBox1.Controls.Add(this.cardnum2_txtbox);
            this.groupBox1.Controls.Add(this.cardnum3_txtbox);
            this.groupBox1.Controls.Add(this.cardnum4_txtbox);
            this.groupBox1.Controls.Add(this.month_txtbox);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.year_txtbox);
            this.groupBox1.Location = new System.Drawing.Point(22, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(635, 173);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "내 카드등록";
            // 
            // deletecard_btn
            // 
            this.deletecard_btn.Location = new System.Drawing.Point(471, 77);
            this.deletecard_btn.Name = "deletecard_btn";
            this.deletecard_btn.Size = new System.Drawing.Size(148, 68);
            this.deletecard_btn.TabIndex = 21;
            this.deletecard_btn.Text = "선택한 카드삭제";
            this.deletecard_btn.UseVisualStyleBackColor = true;
            this.deletecard_btn.Click += new System.EventHandler(this.deletecard_btn_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(159, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 15);
            this.label10.TabIndex = 20;
            this.label10.Text = "유효기간(M/Y)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(158, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 15);
            this.label9.TabIndex = 19;
            this.label9.Text = "카드번호";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.fixaddress_btn);
            this.groupBox2.Controls.Add(this.cwork_radio);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.chome_radio);
            this.groupBox2.Controls.Add(this.deleteaddress_btn);
            this.groupBox2.Controls.Add(this.cdetail_txtbox);
            this.groupBox2.Controls.Add(this.cbasic_txtbox);
            this.groupBox2.Controls.Add(this.cpost_txtbox);
            this.groupBox2.Location = new System.Drawing.Point(22, 633);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(635, 226);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "내 배송지 조회 및 수정, 삭제";
            // 
            // fixaddress_btn
            // 
            this.fixaddress_btn.Location = new System.Drawing.Point(469, 29);
            this.fixaddress_btn.Name = "fixaddress_btn";
            this.fixaddress_btn.Size = new System.Drawing.Size(148, 76);
            this.fixaddress_btn.TabIndex = 27;
            this.fixaddress_btn.Text = "배송지 수정";
            this.fixaddress_btn.UseVisualStyleBackColor = true;
            this.fixaddress_btn.Click += new System.EventHandler(this.fixaddress_btn_Click);
            // 
            // cwork_radio
            // 
            this.cwork_radio.AutoSize = true;
            this.cwork_radio.Location = new System.Drawing.Point(284, 36);
            this.cwork_radio.Name = "cwork_radio";
            this.cwork_radio.Size = new System.Drawing.Size(58, 19);
            this.cwork_radio.TabIndex = 34;
            this.cwork_radio.Text = "직장";
            this.cwork_radio.UseVisualStyleBackColor = true;
            this.cwork_radio.CheckedChanged += new System.EventHandler(this.cwork_radio_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 90);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 15);
            this.label13.TabIndex = 31;
            this.label13.Text = "우편번호";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 132);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 15);
            this.label14.TabIndex = 32;
            this.label14.Text = "기본주소";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 174);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 15);
            this.label15.TabIndex = 33;
            this.label15.Text = "상세주소";
            // 
            // chome_radio
            // 
            this.chome_radio.AutoSize = true;
            this.chome_radio.Location = new System.Drawing.Point(101, 36);
            this.chome_radio.Name = "chome_radio";
            this.chome_radio.Size = new System.Drawing.Size(58, 19);
            this.chome_radio.TabIndex = 30;
            this.chome_radio.Text = "자택";
            this.chome_radio.UseVisualStyleBackColor = true;
            this.chome_radio.CheckedChanged += new System.EventHandler(this.chome_radio_CheckedChanged);
            // 
            // deleteaddress_btn
            // 
            this.deleteaddress_btn.Location = new System.Drawing.Point(469, 132);
            this.deleteaddress_btn.Name = "deleteaddress_btn";
            this.deleteaddress_btn.Size = new System.Drawing.Size(148, 76);
            this.deleteaddress_btn.TabIndex = 22;
            this.deleteaddress_btn.Text = "선택한 배송지 삭제";
            this.deleteaddress_btn.UseVisualStyleBackColor = true;
            this.deleteaddress_btn.Click += new System.EventHandler(this.deleteaddress_btn_Click);
            // 
            // cdetail_txtbox
            // 
            this.cdetail_txtbox.Location = new System.Drawing.Point(101, 174);
            this.cdetail_txtbox.Name = "cdetail_txtbox";
            this.cdetail_txtbox.Size = new System.Drawing.Size(309, 25);
            this.cdetail_txtbox.TabIndex = 28;
            // 
            // cbasic_txtbox
            // 
            this.cbasic_txtbox.Location = new System.Drawing.Point(101, 132);
            this.cbasic_txtbox.Name = "cbasic_txtbox";
            this.cbasic_txtbox.Size = new System.Drawing.Size(309, 25);
            this.cbasic_txtbox.TabIndex = 27;
            // 
            // cpost_txtbox
            // 
            this.cpost_txtbox.Location = new System.Drawing.Point(101, 87);
            this.cpost_txtbox.Name = "cpost_txtbox";
            this.cpost_txtbox.Size = new System.Drawing.Size(309, 25);
            this.cpost_txtbox.TabIndex = 22;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.detail_txtbox);
            this.groupBox3.Controls.Add(this.home_radio);
            this.groupBox3.Controls.Add(this.work_radio);
            this.groupBox3.Controls.Add(this.addaddress_btn);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.basic_txtbox);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.post_txtbox);
            this.groupBox3.Location = new System.Drawing.Point(22, 414);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(635, 213);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "내 배송지 등록";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.deletecard_btn);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.m_y_txtbox);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.cardnum_txtbox);
            this.groupBox4.Controls.Add(this.mycard_cbox);
            this.groupBox4.Location = new System.Drawing.Point(22, 251);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(635, 157);
            this.groupBox4.TabIndex = 32;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "내 카드 조회 및 삭제";
            // 
            // mypage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(676, 866);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.information_btn);
            this.Controls.Add(this.id_label);
            this.Controls.Add(this.name_label);
            this.Controls.Add(this.basket_btn);
            this.Controls.Add(this.orderview_btn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "mypage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "마이페이지";
            this.Load += new System.EventHandler(this.mypage_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button orderview_btn;
        private System.Windows.Forms.Button addcard_btn;
        private System.Windows.Forms.Button addaddress_btn;
        private System.Windows.Forms.Button basket_btn;
        private System.Windows.Forms.ComboBox mycard_cbox;
        private System.Windows.Forms.TextBox cardnum_txtbox;
        private System.Windows.Forms.TextBox m_y_txtbox;
        private System.Windows.Forms.ComboBox card_cbox;
        private System.Windows.Forms.TextBox cardnum1_txtbox;
        private System.Windows.Forms.TextBox cardnum2_txtbox;
        private System.Windows.Forms.TextBox cardnum3_txtbox;
        private System.Windows.Forms.TextBox cardnum4_txtbox;
        private System.Windows.Forms.TextBox month_txtbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox year_txtbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox detail_txtbox;
        private System.Windows.Forms.TextBox basic_txtbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox post_txtbox;
        private System.Windows.Forms.RadioButton work_radio;
        private System.Windows.Forms.RadioButton home_radio;
        private System.Windows.Forms.Label name_label;
        private System.Windows.Forms.Label id_label;
        private System.Windows.Forms.Button information_btn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button deletecard_btn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button deleteaddress_btn;
        private System.Windows.Forms.TextBox cdetail_txtbox;
        private System.Windows.Forms.TextBox cbasic_txtbox;
        private System.Windows.Forms.TextBox cpost_txtbox;
        private System.Windows.Forms.RadioButton cwork_radio;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton chome_radio;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button fixaddress_btn;
        private System.Windows.Forms.GroupBox groupBox4;
    }
}